import json

file_path = '/home/hussainsulaiman/Trainings/ERP Project/Project Files/Development/vb_app_extracted/webApps/supplierportal/flows/item-1/pages/item-1-start-page.json'

with open(file_path, 'r') as f:
    data = json.load(f)

# 1. Variables
if 'editingRuleCode' in data['variables']:
    del data['variables']['editingRuleCode']
if 'editRuleWeight' in data['variables']:
    del data['variables']['editRuleWeight']

# 2. Event Listeners
for el in ['onStartEditRule', 'onCancelEditRule', 'onSaveRuleWeight', 'onEditRuleWeightInput']:
    if el in data['eventListeners']:
        del data['eventListeners'][el]

data['eventListeners']['onRuleWeightChange'] = {
    "chains": [{
        "chainId": "onRuleWeightChangeChain",
        "parameters": {
            "ruleCode": "{{ $event.currentTarget.dataset.ruleCode }}",
            "newWeight": "{{ $event.target.value }}"
        }
    }]
}

data['eventListeners']['onSaveAllRules'] = {
    "chains": [{ "chainId": "saveAllRulesChain" }]
}

# 3. Action Chains
for c in ['startEditRuleChain', 'cancelEditRuleChain', 'saveRuleWeightChain', 'onEditRuleWeightInputChain']:
    if c in data['chains']:
        del data['chains'][c]

data['chains']['onRuleWeightChangeChain'] = {
    "variables": {
        "ruleCode": { "type": "string", "input": "fromCaller" },
        "newWeight": { "type": "string", "input": "fromCaller" }
    },
    "root": "updateArray",
    "actions": {
        "updateArray": {
            "module": "vb/action/builtin/assignVariablesAction",
            "parameters": {
                "$page.variables.riskRules": {
                    "source": "{{ $functions.updateRuleWeight($page.variables.riskRules, $chain.variables.ruleCode, $chain.variables.newWeight) }}"
                }
            }
        }
    }
}

data['chains']['saveAllRulesChain'] = {
    "root": "setBusy",
    "actions": {
        "setBusy": {
            "module": "vb/action/builtin/assignVariablesAction",
            "parameters": {
                "$page.variables.ruleUpdateBusy": { "source": "{{ true }}" },
                "$page.variables.ruleUpdateMessage": { "source": "" }
            },
            "outcomes": { "success": "loopRules" }
        },
        "loopRules": {
            "module": "vb/action/builtin/forEachAction",
            "parameters": {
                "items": "{{ $page.variables.riskRules }}",
                "actionId": "callPUT"
            },
            "outcomes": { "success": "saveSuccess" }
        },
        "callPUT": {
            "module": "vb/action/builtin/restAction",
            "parameters": {
                "endpoint": "ORDS-Specification/updateRiskRule",
                "uriParams": {
                    "rule_code": "{{ $current.data.rule_code }}",
                    "actor_subject_id": "{{ $functions.actorSubjectId($page.variables.currentRole) }}",
                    "actor_roles": "{{ $page.variables.currentRole }}"
                },
                "body": {
                    "weight": "{{ $current.data.weight }}",
                    "active": "{{ $current.data.active }}"
                }
            }
        },
        "saveSuccess": {
            "module": "vb/action/builtin/assignVariablesAction",
            "parameters": {
                "$page.variables.ruleUpdateBusy": { "source": "{{ false }}" },
                "$page.variables.ruleUpdateMessage": { "source": "All rules updated successfully." }
            },
            "outcomes": { "success": "reload" }
        },
        "reload": {
            "module": "vb/action/builtin/callChainAction",
            "parameters": { "id": "loadAdminConfigChain" }
        }
    }
}

with open(file_path, 'w') as f:
    json.dump(data, f, indent=2)

print("JSON updated successfully.")
